# server-aula

docker run --name mysql -e MYSQL_USER=mysql  -e MYSQL_PASSWORD=mysql -e MYSQL_DATABASE=test -p 3306:3306 -e MYSQL_ROOT_PASSWORD=mysql  -d mysql:8
