/*
  Warnings:

  - Added the required column `quantity` to the `BoughtBy` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `BoughtBy` ADD COLUMN `quantity` INTEGER NOT NULL;
