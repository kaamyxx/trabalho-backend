const express = require("express");
const { saveRecipe, getAllRecipes, getRecipeById, updateRecipe, deleteRecipe } = require("../database/recipes");
const router = express.Router();

router.get("/recipes", async (req, res) => {
    const moreThan = req.query.more_than ? Number(req.query.more_than) : 0;
    const recipes = await getAllRecipes(moreThan);
    res.json({
        Recipes
    })
})

router.get("/recipes/:id", async (req, res) => {
    const id = Number(req.params.id);
    const recipe = await getRecipeById(id)
    res.json({
        recipe
    })
})

router.post("/recipes", async (req, res) => {
    const newRecipe = {
        name: req.body.name,
        description: req.body.description,
        time: req.body.time
    }
    const savedRecipe = await saveRecipe(newRecipe)
    res.json({
        recipe: savedRecipe
    })
})

router.put("/recipes/:id", async (req, res) => {
    const id = Number(req.params.id);
    const recipe = {
        name: req.body.name,
        description: req.body.description,
        time: req.body.time
    }
    const updatedRecipe = await updateRecipe(id, recipe);
    res.json({
        recipe: updatedRecipe
    })
})

router.delete("/recipes/:id", async (req, res) => {
    const id = Number(req.params.id);
    await deleteRecipe(id);
    res.status(204).send();
})

module.exports = {
    router
}